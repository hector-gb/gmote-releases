#!/bin/bash

CHROME="/opt/homebrew/bin/chrome-cli"

# Ensure Chrome is active so chrome-cli can communicate
osascript -e 'tell application "Google Chrome" to activate'
sleep 0.1

# Find the Meet tab
TAB_ID=$($CHROME list tabs | grep -E "\] Meet - " | awk '{print $1}' | sed 's/\[//; s/]//; s/.*://')

if [ -n "$TAB_ID" ]; then
    # First activate the tab (switches to it within the window)
    $CHROME activate -t "$TAB_ID"
    
    # Small delay to let the tab switch happen
    sleep 0.25
    
    # Now use --focus to bring that window to front
    $CHROME activate -t "$TAB_ID" --focus
else
    echo "No active Google Meet meeting tab found."
fi