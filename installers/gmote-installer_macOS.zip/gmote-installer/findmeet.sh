#!/bin/bash

LOG=~/tmp/gmote.log
exec >> "$LOG" 2>&1
echo "--- $(date) ---"

CHROME="/opt/homebrew/bin/chrome-cli"

_GMOTE_PORT=$(ls /dev/cu.usbmodem* 2>/dev/null | sort | head -n 1)
echo "gmote port: ${_GMOTE_PORT:-none}"

# Open the port once and keep it open — reopening each time toggles DTR which can reset the board.
if [ -n "$_GMOTE_PORT" ]; then
    stty -f "$_GMOTE_PORT" -hupcl 2>/dev/null  # prevent DTR drop on close
    if exec 3<> "$_GMOTE_PORT"; then
        echo "port fd open: ok"
    else
        echo "port fd open: FAILED"
        _GMOTE_PORT=""
    fi
fi
trap '[ -n "$_GMOTE_PORT" ] && { printf "done\n" >&3 && echo "sent: done" || echo "ERROR: done NOT sent"; exec 3>&-; }; true' EXIT

ACTIVE_TAB_TITLE=$($CHROME info 2>/dev/null | grep -E "^Title:" | sed 's/^Title: //')
echo "active tab: ${ACTIVE_TAB_TITLE:-unknown}"

if echo "$ACTIVE_TAB_TITLE" | grep -qE "^Meet - "; then
    echo "already on Meet tab, bringing Chrome to front..."
    open -a "Google Chrome"
    sleep 0.15
    exit 0
fi

TAB_ID=$($CHROME list tabs 2>/dev/null | grep -E "\] Meet - " | awk '{print $1}' | sed 's/\[//; s/]//; s/.*://')
echo "meet tab id: ${TAB_ID:-not found}"

if [ -n "$TAB_ID" ]; then
    echo "focusing Meet tab..."
    open -a "Google Chrome"
    $CHROME activate -t "$TAB_ID" --focus

    # Poll until chrome-cli confirms Meet is the active tab (up to 1s), then buffer for JS readiness.
    for _ in 1 2 3 4 5 6 7 8 9 10; do
        CURRENT=$($CHROME info 2>/dev/null | grep -E "^Title:" | sed 's/^Title: //')
        echo "waiting for Meet... current: $CURRENT"
        if echo "$CURRENT" | grep -qE "^Meet - "; then
            break
        fi
        sleep 0.1
    done
    sleep 0.3
fi

exit 0
