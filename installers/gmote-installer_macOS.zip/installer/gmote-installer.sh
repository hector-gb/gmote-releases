#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FINDMEET_SRC="$SCRIPT_DIR/findmeet.sh"
INSTALL_DIR="$HOME/Library/Scripts/gmote"
FINDMEET_DEST="$INSTALL_DIR/findmeet.sh"

WORKFLOW_DIR="$HOME/Library/Services"
WORKFLOW_NAME="Find Meet Tab.workflow"
WORKFLOW_PATH="$WORKFLOW_DIR/$WORKFLOW_NAME"

SERVICE_NAME="Find Meet Tab"
SHORTCUT_KEY="^@m"  # Control+Command+M

echo "=== gmote installer ==="
echo ""

# ── 1. Check findmeet.sh ──────────────────────────────────────────────────────
if [ ! -f "$FINDMEET_SRC" ]; then
    echo "Error: findmeet.sh not found in $SCRIPT_DIR"
    echo "Please ensure findmeet.sh is in the same folder as this installer."
    exit 1
fi
echo "[1/4] Found findmeet.sh"

# ── 2. Check / install chrome-cli ────────────────────────────────────────────
if ! command -v chrome-cli &>/dev/null; then
    echo "[2/4] chrome-cli not found — installing via Homebrew..."
    if ! command -v brew &>/dev/null; then
        echo "      Homebrew not found — installing Homebrew..."
        /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    fi
    brew install chrome-cli
else
    echo "[2/4] chrome-cli already installed"
fi

# ── 3. Copy findmeet.sh to stable location ────────────────────────────────────
mkdir -p "$INSTALL_DIR"
cp "$FINDMEET_SRC" "$FINDMEET_DEST"
chmod +x "$FINDMEET_DEST"
echo "[3/4] Installed findmeet.sh → $FINDMEET_DEST"

# ── 4. Create Automator Quick Action ──────────────────────────────────────────
mkdir -p "$WORKFLOW_PATH/Contents"

cat > "$WORKFLOW_PATH/Contents/Info.plist" << 'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>NSServices</key>
    <array>
        <dict>
            <key>NSMenuItem</key>
            <dict>
                <key>default</key>
                <string>Find Meet Tab</string>
            </dict>
            <key>NSMessage</key>
            <string>runWorkflowAsService</string>
            <key>NSSendTypes</key>
            <array/>
        </dict>
    </array>
</dict>
</plist>
PLIST

cat > "$WORKFLOW_PATH/Contents/document.wflow" << WFLOW
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>AMApplicationBuild</key>
    <string>523</string>
    <key>AMApplicationVersion</key>
    <string>2.10</string>
    <key>AMDocumentVersion</key>
    <string>2</string>
    <key>actions</key>
    <array>
        <dict>
            <key>action</key>
            <dict>
                <key>AMAccepts</key>
                <dict>
                    <key>Container</key>
                    <string>List</string>
                    <key>Optional</key>
                    <true/>
                    <key>Types</key>
                    <array>
                        <string>com.apple.cocoa.string</string>
                    </array>
                </dict>
                <key>AMActionVersion</key>
                <string>2.0.3</string>
                <key>AMApplication</key>
                <array>
                    <string>Automator</string>
                </array>
                <key>AMParameterProperties</key>
                <dict>
                    <key>COMMAND_STRING</key>
                    <dict/>
                    <key>inputMethod</key>
                    <dict/>
                    <key>shell</key>
                    <dict/>
                    <key>source</key>
                    <dict/>
                </dict>
                <key>AMProvides</key>
                <dict>
                    <key>Container</key>
                    <string>List</string>
                    <key>Types</key>
                    <array>
                        <string>com.apple.cocoa.string</string>
                    </array>
                </dict>
                <key>ActionBundlePath</key>
                <string>/System/Library/Automator/Run Shell Script.action</string>
                <key>ActionName</key>
                <string>Run Shell Script</string>
                <key>ActionParameters</key>
                <dict>
                    <key>COMMAND_STRING</key>
                    <string>$FINDMEET_DEST</string>
                    <key>inputMethod</key>
                    <integer>0</integer>
                    <key>shell</key>
                    <string>/bin/zsh</string>
                    <key>source</key>
                    <string></string>
                </dict>
                <key>BundleIdentifier</key>
                <string>com.apple.RunShellScript</string>
                <key>CFBundleVersion</key>
                <string>2.0.3</string>
                <key>CanShowSelectedItemsWhenRun</key>
                <false/>
                <key>CanShowWhenRun</key>
                <true/>
                <key>Category</key>
                <array>
                    <string>AMCategoryUtilities</string>
                </array>
                <key>Class Name</key>
                <string>RunShellScriptAction</string>
                <key>InputUUID</key>
                <string>12345678-1234-1234-1234-123456789012</string>
                <key>Keywords</key>
                <array>
                    <string>Shell</string>
                    <string>Script</string>
                    <string>Command</string>
                    <string>Run</string>
                    <string>Unix</string>
                </array>
                <key>OutputUUID</key>
                <string>12345678-1234-1234-1234-123456789013</string>
                <key>UUID</key>
                <string>12345678-1234-1234-1234-123456789014</string>
                <key>UnlocalizedApplications</key>
                <array>
                    <string>Automator</string>
                </array>
                <key>arguments</key>
                <dict>
                    <key>0</key>
                    <dict>
                        <key>default value</key>
                        <integer>0</integer>
                        <key>name</key>
                        <string>inputMethod</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>0</string>
                    </dict>
                    <key>1</key>
                    <dict>
                        <key>default value</key>
                        <false/>
                        <key>name</key>
                        <string>CheckedForUserDefaultShell</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>1</string>
                    </dict>
                    <key>2</key>
                    <dict>
                        <key>default value</key>
                        <string></string>
                        <key>name</key>
                        <string>source</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>2</string>
                    </dict>
                    <key>3</key>
                    <dict>
                        <key>default value</key>
                        <string></string>
                        <key>name</key>
                        <string>COMMAND_STRING</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>3</string>
                    </dict>
                    <key>4</key>
                    <dict>
                        <key>default value</key>
                        <string>/bin/zsh</string>
                        <key>name</key>
                        <string>shell</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>4</string>
                    </dict>
                </dict>
                <key>isViewVisible</key>
                <integer>1</integer>
                <key>location</key>
                <string>309.000000:316.000000</string>
                <key>nibPath</key>
                <string>/System/Library/Automator/Run Shell Script.action/Contents/Resources/Base.lproj/main.nib</string>
            </dict>
            <key>isViewVisible</key>
            <integer>1</integer>
        </dict>
    </array>
    <key>connectors</key>
    <dict/>
    <key>workflowMetaData</key>
    <dict>
        <key>workflowTypeIdentifier</key>
        <string>com.apple.Automator.servicesMenu</string>
        <key>serviceInputTypeIdentifier</key>
        <string>com.apple.Automator.noInput</string>
        <key>serviceProcessesInput</key>
        <integer>0</integer>
    </dict>
</dict>
</plist>
WFLOW

# ── 5. Set keyboard shortcut (Control+Command+M) ──────────────────────────────
defaults write pbs NSServicesStatus -dict-add "\"(null) - $SERVICE_NAME - runWorkflowAsService\"" '{
  "enabled_context_menu" = 1;
  "enabled_services_menu" = 1;
  "key_equivalent" = "'"$SHORTCUT_KEY"'";
}'
/System/Library/CoreServices/pbs -flush

echo "[4/4] Registered Quick Action + shortcut (⌃⌘M)"
echo ""
echo "=== Installation complete ==="
echo "You may need to log out and back in for the shortcut to appear."
