#!/bin/bash

CHROME="/opt/homebrew/bin/chrome-cli"

# Signal the gmote macropad over USB CDC data that focus work is done.
# The data port is the highest-numbered usbmodem (console is the lower one).
_GMOTE_PORT=$(ls /dev/cu.usbmodem* 2>/dev/null | sort | tail -n 1)
trap '[ -n "$_GMOTE_PORT" ] && printf "done\n" > "$_GMOTE_PORT" 2>/dev/null; true' EXIT

# --- Modification 1: If Chrome is already frontmost AND the active tab is a Meet tab, do nothing ---
# Use Chrome's own AppleScript interface to avoid System Events permission prompts
CHROME_FRONTMOST=$(osascript -e 'tell application "Google Chrome" to get frontmost of window 1' 2>/dev/null)

if [ "$CHROME_FRONTMOST" = "true" ]; then
    # Check if the currently active tab in Chrome is already a Meet tab
    ACTIVE_TAB_TITLE=$($CHROME info 2>/dev/null | grep -E "^Title:" | sed 's/^Title: //')
    if echo "$ACTIVE_TAB_TITLE" | grep -qE "^Meet - "; then
        exit 0
    fi
fi

# Find the Meet tab (chrome-cli can list tabs even if Chrome isn't frontmost)
TAB_ID=$($CHROME list tabs 2>/dev/null | grep -E "\] Meet - " | awk '{print $1}' | sed 's/\[//; s/]//; s/.*://')

if [ -n "$TAB_ID" ]; then
    # Only bring Chrome forward if we actually found a Meet tab
    osascript -e 'tell application "Google Chrome" to activate'
    sleep 0.25

    # First activate the tab (switches to it within the window)
    $CHROME activate -t "$TAB_ID"

    # Small delay to let the tab switch happen
    sleep 0.25

    # Now use --focus to bring that window to front
    $CHROME activate -t "$TAB_ID" --focus

fi

exit 0
