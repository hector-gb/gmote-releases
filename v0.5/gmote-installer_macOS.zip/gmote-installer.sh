#!/bin/bash

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FINDMEET_SRC="$SCRIPT_DIR/findmeet.sh"
INSTALL_DIR="$HOME/Library/Scripts/gmote"
FINDMEET_DEST="$INSTALL_DIR/findmeet.sh"

WORKFLOW_DIR="$HOME/Library/Services"

# One Quick Action per button. The hotkey is how the Mac learns WHICH button
# was pressed — the board sends a different obscure combo for each.
#   ^ = Control   ~ = Option   $ = Shift   @ = Command
#
# All four use Control+Option+Shift+Command. Three-modifier combos collide with
# real apps (^~@n was already taken by VS Code); a four-modifier chord is
# essentially unclaimed.
#
# NOTE: single-quoted on purpose — "$@" in a double-quoted string would expand
# to the script's positional parameters.
#
#   service name|action arg|key_equivalent
ACTIONS=(
    'Gmote Mic|mic|^~$@m'
    'Gmote Camera|camera|^~$@n'
    'Gmote Hand|hand|^~$@j'
    'Gmote Leave|leave|^~$@k'
)

# Leftovers from the old single-service install.
#
# The bundle and the binding are checked SEPARATELY on purpose — they drift out
# of sync. An earlier installer deleted the bundle but left the binding behind,
# so gating the binding cleanup on "does the bundle exist?" would never clean it.
LEGACY_NAME="Find Meet Tab"
LEGACY_WORKFLOW="$WORKFLOW_DIR/$LEGACY_NAME.workflow"
PBS_PLIST="$HOME/Library/Preferences/pbs.plist"
LEGACY_KEY=":NSServicesStatus:\"(null) - $LEGACY_NAME - runWorkflowAsService\""

remove_legacy() {
    local did=0

    if [ -d "$LEGACY_WORKFLOW" ]; then
        rm -rf "$LEGACY_WORKFLOW"
        echo "      removed old Quick Action: $LEGACY_NAME"
        did=1
    fi

    # `defaults` can only delete a whole key, and NSServicesStatus holds every
    # app's service shortcuts — deleting it would wipe unrelated ones.
    # PlistBuddy can remove just this one nested entry.
    if [ -f "$PBS_PLIST" ] && /usr/libexec/PlistBuddy -c "Print $LEGACY_KEY" "$PBS_PLIST" >/dev/null 2>&1; then
        if /usr/libexec/PlistBuddy -c "Delete $LEGACY_KEY" "$PBS_PLIST" >/dev/null 2>&1; then
            echo "      removed old shortcut binding: $LEGACY_NAME"
            did=1
        else
            echo "      WARNING: could not remove binding for $LEGACY_NAME"
        fi
    fi

    if [ "$did" -eq 0 ]; then
        echo "      nothing to clean"
    fi
    return 0
}

echo "=== gmote installer ==="
echo ""

# ── 1. Check findmeet.sh ──────────────────────────────────────────────────────
if [ ! -f "$FINDMEET_SRC" ]; then
    echo "Error: findmeet.sh not found in $SCRIPT_DIR"
    echo "Please ensure findmeet.sh is in the same folder as this installer."
    exit 1
fi
echo "[1/4] Found findmeet.sh"

# ── 2. Copy findmeet.sh to stable location ────────────────────────────────────
mkdir -p "$INSTALL_DIR"
cp "$FINDMEET_SRC" "$FINDMEET_DEST"
chmod +x "$FINDMEET_DEST"
echo "[2/4] Installed findmeet.sh → $FINDMEET_DEST"
echo "      (no chrome-cli needed — uses Chrome's own AppleScript)"

# ── 3. Create one Quick Action per action + bind its shortcut ─────────────────
make_workflow() {
    local service_name="$1"
    local command_string="$2"
    local workflow_path="$WORKFLOW_DIR/${service_name}.workflow"

    rm -rf "$workflow_path"
    mkdir -p "$workflow_path/Contents"

    cat > "$workflow_path/Contents/Info.plist" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>NSServices</key>
    <array>
        <dict>
            <key>NSMenuItem</key>
            <dict>
                <key>default</key>
                <string>${service_name}</string>
            </dict>
            <key>NSMessage</key>
            <string>runWorkflowAsService</string>
        </dict>
    </array>
</dict>
</plist>
PLIST

    cat > "$workflow_path/Contents/document.wflow" << WFLOW
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>AMApplicationBuild</key>
    <string>523</string>
    <key>AMApplicationVersion</key>
    <string>2.10</string>
    <key>AMDocumentVersion</key>
    <string>2</string>
    <key>actions</key>
    <array>
        <dict>
            <key>action</key>
            <dict>
                <key>AMAccepts</key>
                <dict>
                    <key>Container</key>
                    <string>List</string>
                    <key>Optional</key>
                    <true/>
                    <key>Types</key>
                    <array>
                        <string>com.apple.cocoa.string</string>
                    </array>
                </dict>
                <key>AMActionVersion</key>
                <string>2.0.3</string>
                <key>AMApplication</key>
                <array>
                    <string>Automator</string>
                </array>
                <key>AMParameterProperties</key>
                <dict>
                    <key>COMMAND_STRING</key>
                    <dict/>
                    <key>inputMethod</key>
                    <dict/>
                    <key>shell</key>
                    <dict/>
                    <key>source</key>
                    <dict/>
                </dict>
                <key>AMProvides</key>
                <dict>
                    <key>Container</key>
                    <string>List</string>
                    <key>Types</key>
                    <array>
                        <string>com.apple.cocoa.string</string>
                    </array>
                </dict>
                <key>ActionBundlePath</key>
                <string>/System/Library/Automator/Run Shell Script.action</string>
                <key>ActionName</key>
                <string>Run Shell Script</string>
                <key>ActionParameters</key>
                <dict>
                    <key>COMMAND_STRING</key>
                    <string>${command_string}</string>
                    <key>inputMethod</key>
                    <integer>0</integer>
                    <key>shell</key>
                    <string>/bin/zsh</string>
                    <key>source</key>
                    <string></string>
                </dict>
                <key>BundleIdentifier</key>
                <string>com.apple.RunShellScript</string>
                <key>CFBundleVersion</key>
                <string>2.0.3</string>
                <key>CanShowSelectedItemsWhenRun</key>
                <false/>
                <key>CanShowWhenRun</key>
                <true/>
                <key>Category</key>
                <array>
                    <string>AMCategoryUtilities</string>
                </array>
                <key>Class Name</key>
                <string>RunShellScriptAction</string>
                <key>InputUUID</key>
                <string>12345678-1234-1234-1234-123456789012</string>
                <key>Keywords</key>
                <array>
                    <string>Shell</string>
                    <string>Script</string>
                    <string>Command</string>
                    <string>Run</string>
                    <string>Unix</string>
                </array>
                <key>OutputUUID</key>
                <string>12345678-1234-1234-1234-123456789013</string>
                <key>UUID</key>
                <string>12345678-1234-1234-1234-123456789014</string>
                <key>UnlocalizedApplications</key>
                <array>
                    <string>Automator</string>
                </array>
                <key>arguments</key>
                <dict>
                    <key>0</key>
                    <dict>
                        <key>default value</key>
                        <integer>0</integer>
                        <key>name</key>
                        <string>inputMethod</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>0</string>
                    </dict>
                    <key>1</key>
                    <dict>
                        <key>default value</key>
                        <false/>
                        <key>name</key>
                        <string>CheckedForUserDefaultShell</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>1</string>
                    </dict>
                    <key>2</key>
                    <dict>
                        <key>default value</key>
                        <string></string>
                        <key>name</key>
                        <string>source</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>2</string>
                    </dict>
                    <key>3</key>
                    <dict>
                        <key>default value</key>
                        <string></string>
                        <key>name</key>
                        <string>COMMAND_STRING</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>3</string>
                    </dict>
                    <key>4</key>
                    <dict>
                        <key>default value</key>
                        <string>/bin/zsh</string>
                        <key>name</key>
                        <string>shell</string>
                        <key>required</key>
                        <string>0</string>
                        <key>type</key>
                        <string>0</string>
                        <key>uuid</key>
                        <string>4</string>
                    </dict>
                </dict>
                <key>isViewVisible</key>
                <integer>1</integer>
                <key>location</key>
                <string>309.000000:316.000000</string>
                <key>nibPath</key>
                <string>/System/Library/Automator/Run Shell Script.action/Contents/Resources/Base.lproj/main.nib</string>
            </dict>
            <key>isViewVisible</key>
            <integer>1</integer>
        </dict>
    </array>
    <key>connectors</key>
    <dict/>
    <key>workflowMetaData</key>
    <dict>
        <key>applicationBundleIDsByPath</key>
        <dict/>
        <key>applicationPaths</key>
        <array/>
        <key>inputTypeIdentifier</key>
        <string>com.apple.Automator.nothing</string>
        <key>outputTypeIdentifier</key>
        <string>com.apple.Automator.nothing</string>
        <key>presentationMode</key>
        <integer>11</integer>
        <key>processesInput</key>
        <false/>
        <key>serviceInputTypeIdentifier</key>
        <string>com.apple.Automator.nothing</string>
        <key>serviceOutputTypeIdentifier</key>
        <string>com.apple.Automator.nothing</string>
        <key>serviceProcessesInput</key>
        <false/>
        <key>systemImageName</key>
        <string>NSActionTemplate</string>
        <key>useAutomaticInputType</key>
        <false/>
        <key>workflowTypeIdentifier</key>
        <string>com.apple.Automator.servicesMenu</string>
    </dict>
</dict>
</plist>
WFLOW
}

for entry in "${ACTIONS[@]}"; do
    IFS='|' read -r NAME ACTION KEY <<< "$entry"

    make_workflow "$NAME" "$FINDMEET_DEST $ACTION"

    defaults write pbs NSServicesStatus -dict-add "\"(null) - $NAME - runWorkflowAsService\"" "{
      \"enabled_context_menu\" = 1;
      \"enabled_services_menu\" = 1;
      \"key_equivalent\" = \"$KEY\";
    }"

    echo "      $NAME → '$ACTION'  ($KEY)"
done

echo "[3/4] Registered 4 Quick Actions + shortcuts"

# ── 4. Clean up leftovers from the old single-service install ─────────────────
# Runs after the writes above so our PlistBuddy edit is the last thing to touch
# the file; the flush then makes pbs reload the result.
echo "[4/4] Checking for leftovers from older installs"
remove_legacy

/System/Library/CoreServices/pbs -flush
echo ""
echo "=== Installation complete ==="
echo ""
echo "IMPORTANT — grant Accessibility permission:"
echo "  These send keystrokes to Meet via System Events, which macOS gates."
echo "  The first button press will either prompt, or silently do nothing."
echo "  If nothing happens, add Automator (and/or zsh) under:"
echo "    System Settings → Privacy & Security → Accessibility"
echo ""
echo "You may need to log out and back in for the shortcuts to appear."
echo "Logs: ~/tmp/gmote.log"
