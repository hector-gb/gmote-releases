#!/bin/bash
# findmeet.sh <mic|camera|hand|leave>
#
# Brings the Meet tab to the front, waits until Chrome is ACTUALLY frontmost
# with Meet as the active tab, and only then sends that action's Meet shortcut.
#
# The point: the board no longer guesses how long focusing takes. If focus
# can't be confirmed within FOCUS_TIMEOUT, we send nothing — a no-op is much
# better than firing Cmd+D into whatever app happens to be in front.
#
# No chrome-cli: Chrome's own AppleScript does find+focus in one round trip
# (~0.7s vs ~2.3s for `chrome-cli list tabs` with 30 tabs open).

set -u

mkdir -p ~/tmp
LOG=~/tmp/gmote.log
exec >> "$LOG" 2>&1

ACTION="${1:-}"
FOCUS_TIMEOUT=3.0   # seconds to wait for Meet to actually come frontmost
POLL_S=0.03         # each state read already costs ~250ms, so this is just padding

START=$(date +%s.%N)
log() { printf '[%6.0fms] %s\n' "$(echo "($(date +%s.%N) - $START) * 1000" | bc)" "$*"; }

echo "--- $(date) --- action=${ACTION:-<none>}"

# action -> Meet keyboard shortcut (as AppleScript keystroke + modifiers)
case "$ACTION" in
    mic)    KEY="d"; MODS="command down" ;;
    camera) KEY="e"; MODS="command down" ;;
    hand)   KEY="h"; MODS="control down, command down" ;;
    leave)  KEY="w"; MODS="command down" ;;
    *) log "unknown action '${ACTION}' (want mic|camera|hand|leave)"; exit 2 ;;
esac

# Chrome's own `frontmost` needs no Accessibility permission — only the
# keystroke at the very end does.
chrome_state() {
    osascript 2>/dev/null <<'EOS'
tell application "Google Chrome"
    set f to frontmost
    set t to ""
    try
        set t to title of active tab of front window
    end try
    return (f as string) & "|" & t
end tell
EOS
}

# Find the Meet tab, make it active in its window, then actually raise that
# window and bring Chrome forward.
#
# NOTE: `set index of w to 1` does NOT work — measured with 3 windows open, the
# Meet window stayed at idx=2 while an unrelated window kept the front spot, so
# the poll below never saw Meet and correctly refused to fire. `perform action
# "AXRaise"` didn't work either. Setting AXMain via System Events does raise it,
# and once genuinely raised, Chrome's own `front window` reporting catches up.
#
# Order matters: set the active tab FIRST so the window's title becomes
# "Meet - ...", which is how System Events then identifies it.
#
# This makes Accessibility a requirement for focusing too — but the keystroke at
# the end already needed it, so it costs no new permission.
focus_meet() {
    osascript <<'EOS'
tell application "Google Chrome"
    set found to false
    repeat with w in windows
        set i to 0
        repeat with t in tabs of w
            set i to i + 1
            if title of t starts with "Meet - " then
                set active tab index of w to i
                set found to true
                exit repeat
            end if
        end repeat
        if found then exit repeat
    end repeat
    if not found then return "none"
    activate
end tell

tell application "System Events" to tell process "Google Chrome"
    set value of attribute "AXMain" of (first window whose name contains "Meet - ") to true
end tell
return "ok"
EOS
}

send_shortcut() {
    osascript -e "tell application \"System Events\" to keystroke \"$KEY\" using {$MODS}" 2>&1
}

FRONT=""; TITLE=""
read_state() {
    local s
    s=$(chrome_state)
    FRONT="${s%%|*}"
    TITLE="${s#*|}"
}

is_meet_ready() {
    [ "$FRONT" = "true" ] && [[ "$TITLE" == Meet\ -* ]]
}

# --- Fast path: already sitting in Meet, send immediately (no focus latency) ---
read_state
if is_meet_ready; then
    log "already frontmost on Meet — sending '$ACTION' now"
    send_shortcut
    log "sent"
    exit 0
fi
log "not ready (frontmost=$FRONT tab='$TITLE') — locating Meet tab"

if [ "$(focus_meet)" != "ok" ]; then
    log "no Meet tab open — nothing to do"
    exit 0
fi
log "focus issued"

# --- Wait for focus to actually land, however long that really takes ---
DEADLINE=$(echo "$(date +%s.%N) + $FOCUS_TIMEOUT" | bc)
while [ "$(echo "$(date +%s.%N) < $DEADLINE" | bc)" -eq 1 ]; do
    read_state
    if is_meet_ready; then
        log "focus confirmed — sending '$ACTION'"
        send_shortcut
        log "sent"
        exit 0
    fi
    sleep "$POLL_S"
done

log "TIMEOUT after ${FOCUS_TIMEOUT}s (frontmost=$FRONT tab='$TITLE') — sending NOTHING"
exit 1
